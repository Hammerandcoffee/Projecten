﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Plus_Click(object sender, EventArgs e)
        {
            // Het programma haalt de twee getallen uit de GetalBoxen en doet +
            double antwoord = double.Parse(Getal1Box.Text) + Double.Parse(Getal2Box.Text);
            UitkomstBox.Text = antwoord.ToString();
        }

        private void Min_Click(object sender, EventArgs e)
        {
            // Het programma haalt de twee getallen uit de GetalBoxen en doet -
            double antwoord = double.Parse(Getal1Box.Text) - Double.Parse(Getal2Box.Text);
            UitkomstBox.Text = antwoord.ToString();
        }

        private void Keer_Click(object sender, EventArgs e)
        {
            // Het programma haalt de twee getallen uit de GetalBoxen en doet *
            double antwoord = double.Parse(Getal1Box.Text) * Double.Parse(Getal2Box.Text);
            UitkomstBox.Text = antwoord.ToString();
        }

        private void Delen_Click(object sender, EventArgs e)
        {
            // Het programma haalt de twee getallen uit de GetalBoxen en doet /
            double antwoord = double.Parse(Getal1Box.Text) / Double.Parse(Getal2Box.Text);
            UitkomstBox.Text = antwoord.ToString();
        }

        private void Wortel_Click(object sender, EventArgs e)
        {
            // Het programma haalt de twee getallen uit de GetalBoxen en doet √
            double antwoord = Math.Sqrt(double.Parse(Getal1Box.Text));
            UitkomstBox.Text = antwoord.ToString();
        }

        private void Kwadraat_Click(object sender, EventArgs e)
        {
            // Het programma haalt de twee getallen uit de GetalBoxen en doet x2
            double antwoord = double.Parse(Getal1Box.Text);
            antwoord = antwoord * antwoord;
            UitkomstBox.Text = antwoord.ToString();
        }

        private void Leegmaken_Click(object sender, EventArgs e)
        {
            // Het programma haalt alle getallen weg
            Getal1Box.Clear();
            Getal2Box.Clear();
            UitkomstBox.Clear();
        }

        
    }
}
