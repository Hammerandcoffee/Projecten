﻿
namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Leegmaken = new System.Windows.Forms.Button();
            this.Plus = new System.Windows.Forms.Button();
            this.Keer = new System.Windows.Forms.Button();
            this.Wortel = new System.Windows.Forms.Button();
            this.Min = new System.Windows.Forms.Button();
            this.Delen = new System.Windows.Forms.Button();
            this.Kwadraat = new System.Windows.Forms.Button();
            this.Getal1Box = new System.Windows.Forms.TextBox();
            this.Getal2Box = new System.Windows.Forms.TextBox();
            this.UitkomstBox = new System.Windows.Forms.TextBox();
            this.Getal1 = new System.Windows.Forms.Label();
            this.Getal2 = new System.Windows.Forms.Label();
            this.Uitkomst = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Leegmaken
            // 
            this.Leegmaken.BackColor = System.Drawing.Color.Blue;
            this.Leegmaken.ForeColor = System.Drawing.Color.White;
            this.Leegmaken.Location = new System.Drawing.Point(121, 224);
            this.Leegmaken.Name = "Leegmaken";
            this.Leegmaken.Size = new System.Drawing.Size(237, 39);
            this.Leegmaken.TabIndex = 1;
            this.Leegmaken.Text = "Leegmaken";
            this.Leegmaken.UseVisualStyleBackColor = false;
            this.Leegmaken.Click += new System.EventHandler(this.Leegmaken_Click);
            // 
            // Plus
            // 
            this.Plus.BackColor = System.Drawing.Color.Blue;
            this.Plus.ForeColor = System.Drawing.Color.White;
            this.Plus.Location = new System.Drawing.Point(121, 284);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(75, 53);
            this.Plus.TabIndex = 2;
            this.Plus.Text = "+";
            this.Plus.UseVisualStyleBackColor = false;
            this.Plus.Click += new System.EventHandler(this.Plus_Click);
            // 
            // Keer
            // 
            this.Keer.BackColor = System.Drawing.Color.Blue;
            this.Keer.ForeColor = System.Drawing.Color.White;
            this.Keer.Location = new System.Drawing.Point(202, 284);
            this.Keer.Name = "Keer";
            this.Keer.Size = new System.Drawing.Size(75, 53);
            this.Keer.TabIndex = 3;
            this.Keer.Text = "*";
            this.Keer.UseVisualStyleBackColor = false;
            this.Keer.Click += new System.EventHandler(this.Keer_Click);
            // 
            // Wortel
            // 
            this.Wortel.BackColor = System.Drawing.Color.Blue;
            this.Wortel.ForeColor = System.Drawing.Color.White;
            this.Wortel.Location = new System.Drawing.Point(283, 284);
            this.Wortel.Name = "Wortel";
            this.Wortel.Size = new System.Drawing.Size(75, 53);
            this.Wortel.TabIndex = 4;
            this.Wortel.Text = "√";
            this.Wortel.UseVisualStyleBackColor = false;
            this.Wortel.Click += new System.EventHandler(this.Wortel_Click);
            // 
            // Min
            // 
            this.Min.BackColor = System.Drawing.Color.Blue;
            this.Min.ForeColor = System.Drawing.Color.White;
            this.Min.Location = new System.Drawing.Point(121, 343);
            this.Min.Name = "Min";
            this.Min.Size = new System.Drawing.Size(75, 58);
            this.Min.TabIndex = 5;
            this.Min.Text = "-";
            this.Min.UseVisualStyleBackColor = false;
            this.Min.Click += new System.EventHandler(this.Min_Click);
            // 
            // Delen
            // 
            this.Delen.BackColor = System.Drawing.Color.Blue;
            this.Delen.ForeColor = System.Drawing.Color.White;
            this.Delen.Location = new System.Drawing.Point(202, 343);
            this.Delen.Name = "Delen";
            this.Delen.Size = new System.Drawing.Size(75, 58);
            this.Delen.TabIndex = 6;
            this.Delen.Text = "/";
            this.Delen.UseVisualStyleBackColor = false;
            this.Delen.Click += new System.EventHandler(this.Delen_Click);
            // 
            // Kwadraat
            // 
            this.Kwadraat.BackColor = System.Drawing.Color.Blue;
            this.Kwadraat.ForeColor = System.Drawing.Color.White;
            this.Kwadraat.Location = new System.Drawing.Point(283, 343);
            this.Kwadraat.Name = "Kwadraat";
            this.Kwadraat.Size = new System.Drawing.Size(75, 58);
            this.Kwadraat.TabIndex = 7;
            this.Kwadraat.Text = "x2";
            this.Kwadraat.UseVisualStyleBackColor = false;
            this.Kwadraat.Click += new System.EventHandler(this.Kwadraat_Click);
            // 
            // Getal1Box
            // 
            this.Getal1Box.BackColor = System.Drawing.Color.Lime;
            this.Getal1Box.Location = new System.Drawing.Point(121, 88);
            this.Getal1Box.Name = "Getal1Box";
            this.Getal1Box.Size = new System.Drawing.Size(237, 22);
            this.Getal1Box.TabIndex = 8;
            // 
            // Getal2Box
            // 
            this.Getal2Box.BackColor = System.Drawing.Color.Lime;
            this.Getal2Box.Location = new System.Drawing.Point(121, 131);
            this.Getal2Box.Name = "Getal2Box";
            this.Getal2Box.Size = new System.Drawing.Size(237, 22);
            this.Getal2Box.TabIndex = 9;
            // 
            // UitkomstBox
            // 
            this.UitkomstBox.BackColor = System.Drawing.Color.Lime;
            this.UitkomstBox.Location = new System.Drawing.Point(121, 179);
            this.UitkomstBox.Name = "UitkomstBox";
            this.UitkomstBox.ReadOnly = true;
            this.UitkomstBox.Size = new System.Drawing.Size(237, 22);
            this.UitkomstBox.TabIndex = 10;
            // 
            // Getal1
            // 
            this.Getal1.AutoSize = true;
            this.Getal1.ForeColor = System.Drawing.Color.White;
            this.Getal1.Location = new System.Drawing.Point(43, 91);
            this.Getal1.Name = "Getal1";
            this.Getal1.Size = new System.Drawing.Size(50, 17);
            this.Getal1.TabIndex = 11;
            this.Getal1.Text = "Getal1";
            // 
            // Getal2
            // 
            this.Getal2.AutoSize = true;
            this.Getal2.ForeColor = System.Drawing.Color.White;
            this.Getal2.Location = new System.Drawing.Point(43, 136);
            this.Getal2.Name = "Getal2";
            this.Getal2.Size = new System.Drawing.Size(50, 17);
            this.Getal2.TabIndex = 12;
            this.Getal2.Text = "Getal2";
            // 
            // Uitkomst
            // 
            this.Uitkomst.AutoSize = true;
            this.Uitkomst.ForeColor = System.Drawing.Color.White;
            this.Uitkomst.Location = new System.Drawing.Point(31, 179);
            this.Uitkomst.Name = "Uitkomst";
            this.Uitkomst.Size = new System.Drawing.Size(62, 17);
            this.Uitkomst.TabIndex = 13;
            this.Uitkomst.Text = "Uitkomst";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(171, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "REKENMACHINE";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(479, 527);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Uitkomst);
            this.Controls.Add(this.Getal2);
            this.Controls.Add(this.Getal1);
            this.Controls.Add(this.UitkomstBox);
            this.Controls.Add(this.Getal2Box);
            this.Controls.Add(this.Getal1Box);
            this.Controls.Add(this.Kwadraat);
            this.Controls.Add(this.Delen);
            this.Controls.Add(this.Min);
            this.Controls.Add(this.Wortel);
            this.Controls.Add(this.Keer);
            this.Controls.Add(this.Plus);
            this.Controls.Add(this.Leegmaken);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Leegmaken;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button Keer;
        private System.Windows.Forms.Button Wortel;
        private System.Windows.Forms.Button Min;
        private System.Windows.Forms.Button Delen;
        private System.Windows.Forms.Button Kwadraat;
        private System.Windows.Forms.TextBox Getal1Box;
        private System.Windows.Forms.TextBox Getal2Box;
        private System.Windows.Forms.TextBox UitkomstBox;
        private System.Windows.Forms.Label Getal1;
        private System.Windows.Forms.Label Getal2;
        private System.Windows.Forms.Label Uitkomst;
        private System.Windows.Forms.Label label1;
    }
}

