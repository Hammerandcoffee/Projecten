﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_programmeertool_software_dev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                LB1.Items.Clear();

                if (RB1_For.Checked)
                {
                    string temp = "";
                    string temp2 = "";
                    string temp3 = "";

                    if (RB12.Checked)
                        temp3 = "<";
                    if (RB10.Checked)
                        temp3 = ">";
                    if (RB11.Checked)
                        temp3 = ">=";
                    if (RB13.Checked)
                        temp3 = "<=";
                    if (RB14.Checked)
                        temp3 = "=";

                    if (RB5_Kleiner_dan.Checked)
                        temp = "<";
                    if (RB4_Groter_dan.Checked)
                        temp = ">";
                    if (RB1.Checked)
                        temp = ">=";
                    if (RB2.Checked)
                        temp = "<=";
                    if (RB3.Checked)
                        temp = "=";
                    if (TB3_Stapgrootte.Text == "1")
                    {
                        if (RB6_Plus.Checked)
                            temp2 = "i++";
                        else if (RB7_Min.Checked)
                            temp2 = "i--";
                        else if (RB4.Checked)
                            temp2 = "i**";
                        else if (RB5.Checked)
                            temp2 = "i//";
                    }
                    else
                    {
                        if (RB6_Plus.Checked)
                            temp2 = $"i += {TB3_Stapgrootte.Text}";
                        else if (RB7_Min.Checked)
                            temp2 = $"i -= {TB3_Stapgrootte.Text}";
                        else if (RB4.Checked)
                            temp2 = $"i *= {TB3_Stapgrootte.Text}";
                        else if (RB5.Checked)
                            temp2 = $"i /= {TB3_Stapgrootte.Text}";
                    }
                    LB1.Items.Add($"int i {temp3} {TB1_Beginwaarde.Text}");
                    LB1.Items.Add($"for (i {temp3} {TB1_Beginwaarde.Text}; i {temp} {TB2_Eindwaarde.Text}; {temp2})");
                    LB1.Items.Add("{");
                    LB1.Items.Add("}");
                }
                else if (RB2_While.Checked)
                {
                    if (RB2_While.Checked)
                    {
                        string temp = "";
                        string temp2 = "";
                        string temp3 = "";

                        if (RB12.Checked)
                            temp3 = "<";
                        if (RB10.Checked)
                            temp3 = ">";
                        if (RB11.Checked)
                            temp3 = ">=";
                        if (RB13.Checked)
                            temp3 = "<=";
                        if (RB14.Checked)
                            temp3 = "=";

                        if (RB5_Kleiner_dan.Checked)
                            temp = "<";
                        if (RB4_Groter_dan.Checked)
                            temp = ">";
                        if (RB1.Checked)
                            temp = ">=";
                        if (RB2.Checked)
                            temp = "<=";
                        if (RB3.Checked)
                            temp = "=";
                        if (TB3_Stapgrootte.Text == "1")
                        {
                            if (RB6_Plus.Checked)
                                temp2 = "i++";
                            else if (RB7_Min.Checked)
                                temp2 = "i--";
                            else if (RB4.Checked)
                                temp2 = "i**";
                            else if (RB5.Checked)
                                temp2 = "i//";
                        }
                        else
                        {
                            if (RB6_Plus.Checked)
                                temp2 = $"i += {TB3_Stapgrootte.Text}";
                            else if (RB7_Min.Checked)
                                temp2 = $"i -= {TB3_Stapgrootte.Text}";
                            else if (RB4.Checked)
                                temp2 = $"i *= {TB3_Stapgrootte.Text}";
                            else if (RB5.Checked)
                                temp2 = $"i /= {TB3_Stapgrootte.Text}";
                        }
                        LB1.Items.Add($"int i {temp3} {TB1_Beginwaarde.Text}");
                        LB1.Items.Add($"while (i {temp} {TB2_Eindwaarde.Text})");
                        LB1.Items.Add("{");
                        LB1.Items.Add($"{temp2};");
                        LB1.Items.Add("}");
                    }
                   
                }


            }
            catch { MessageBox.Show("Er is een fout opgetreden", "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

    }
}
