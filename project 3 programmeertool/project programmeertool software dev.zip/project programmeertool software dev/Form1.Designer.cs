﻿
namespace project_programmeertool_software_dev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.LB1 = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.RB1_For = new System.Windows.Forms.RadioButton();
            this.RB2_While = new System.Windows.Forms.RadioButton();
            this.TB1_Beginwaarde = new System.Windows.Forms.TextBox();
            this.RB4_Groter_dan = new System.Windows.Forms.RadioButton();
            this.RB5_Kleiner_dan = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TB2_Eindwaarde = new System.Windows.Forms.TextBox();
            this.TB3_Stapgrootte = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.RB6_Plus = new System.Windows.Forms.RadioButton();
            this.RB7_Min = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.GB1 = new System.Windows.Forms.GroupBox();
            this.GB2 = new System.Windows.Forms.GroupBox();
            this.RB14 = new System.Windows.Forms.RadioButton();
            this.RB13 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.RB11 = new System.Windows.Forms.RadioButton();
            this.RB12 = new System.Windows.Forms.RadioButton();
            this.RB10 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.GB3 = new System.Windows.Forms.GroupBox();
            this.RB3 = new System.Windows.Forms.RadioButton();
            this.RB2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.RB1 = new System.Windows.Forms.RadioButton();
            this.GB4 = new System.Windows.Forms.GroupBox();
            this.RB5 = new System.Windows.Forms.RadioButton();
            this.RB4 = new System.Windows.Forms.RadioButton();
            this.GB1.SuspendLayout();
            this.GB2.SuspendLayout();
            this.GB3.SuspendLayout();
            this.GB4.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.Location = new System.Drawing.Point(36, 173);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(814, 52);
            this.button1.TabIndex = 0;
            this.button1.Text = "Geef advies";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LB1
            // 
            this.LB1.FormattingEnabled = true;
            this.LB1.ItemHeight = 16;
            this.LB1.Location = new System.Drawing.Point(36, 238);
            this.LB1.Name = "LB1";
            this.LB1.Size = new System.Drawing.Size(814, 276);
            this.LB1.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "Geef beginwaarde";
            // 
            // RB1_For
            // 
            this.RB1_For.AutoSize = true;
            this.RB1_For.Location = new System.Drawing.Point(32, 62);
            this.RB1_For.Name = "RB1_For";
            this.RB1_For.Size = new System.Drawing.Size(50, 21);
            this.RB1_For.TabIndex = 8;
            this.RB1_For.TabStop = true;
            this.RB1_For.Text = "For";
            this.RB1_For.UseVisualStyleBackColor = true;
            // 
            // RB2_While
            // 
            this.RB2_While.AutoSize = true;
            this.RB2_While.Location = new System.Drawing.Point(111, 62);
            this.RB2_While.Name = "RB2_While";
            this.RB2_While.Size = new System.Drawing.Size(64, 21);
            this.RB2_While.TabIndex = 9;
            this.RB2_While.TabStop = true;
            this.RB2_While.Text = "While";
            this.RB2_While.UseVisualStyleBackColor = true;
            // 
            // TB1_Beginwaarde
            // 
            this.TB1_Beginwaarde.Location = new System.Drawing.Point(136, 132);
            this.TB1_Beginwaarde.Name = "TB1_Beginwaarde";
            this.TB1_Beginwaarde.Size = new System.Drawing.Size(47, 22);
            this.TB1_Beginwaarde.TabIndex = 11;
            // 
            // RB4_Groter_dan
            // 
            this.RB4_Groter_dan.AutoSize = true;
            this.RB4_Groter_dan.Location = new System.Drawing.Point(89, 30);
            this.RB4_Groter_dan.Name = "RB4_Groter_dan";
            this.RB4_Groter_dan.Size = new System.Drawing.Size(37, 21);
            this.RB4_Groter_dan.TabIndex = 12;
            this.RB4_Groter_dan.TabStop = true;
            this.RB4_Groter_dan.Text = ">";
            this.RB4_Groter_dan.UseVisualStyleBackColor = true;
            // 
            // RB5_Kleiner_dan
            // 
            this.RB5_Kleiner_dan.AutoSize = true;
            this.RB5_Kleiner_dan.Location = new System.Drawing.Point(89, 60);
            this.RB5_Kleiner_dan.Name = "RB5_Kleiner_dan";
            this.RB5_Kleiner_dan.Size = new System.Drawing.Size(37, 21);
            this.RB5_Kleiner_dan.TabIndex = 13;
            this.RB5_Kleiner_dan.TabStop = true;
            this.RB5_Kleiner_dan.Text = "<";
            this.RB5_Kleiner_dan.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "Groter dan";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 17);
            this.label8.TabIndex = 15;
            this.label8.Text = "Kleiner dan";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "Geef eindwaarde";
            // 
            // TB2_Eindwaarde
            // 
            this.TB2_Eindwaarde.Location = new System.Drawing.Point(127, 131);
            this.TB2_Eindwaarde.Name = "TB2_Eindwaarde";
            this.TB2_Eindwaarde.Size = new System.Drawing.Size(44, 22);
            this.TB2_Eindwaarde.TabIndex = 17;
            // 
            // TB3_Stapgrootte
            // 
            this.TB3_Stapgrootte.Location = new System.Drawing.Point(127, 134);
            this.TB3_Stapgrootte.Name = "TB3_Stapgrootte";
            this.TB3_Stapgrootte.Size = new System.Drawing.Size(44, 22);
            this.TB3_Stapgrootte.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "Rekenkundig";
            // 
            // RB6_Plus
            // 
            this.RB6_Plus.AutoSize = true;
            this.RB6_Plus.Location = new System.Drawing.Point(103, 33);
            this.RB6_Plus.Name = "RB6_Plus";
            this.RB6_Plus.Size = new System.Drawing.Size(37, 21);
            this.RB6_Plus.TabIndex = 20;
            this.RB6_Plus.TabStop = true;
            this.RB6_Plus.Text = "+";
            this.RB6_Plus.UseVisualStyleBackColor = true;
            // 
            // RB7_Min
            // 
            this.RB7_Min.AutoSize = true;
            this.RB7_Min.Location = new System.Drawing.Point(103, 60);
            this.RB7_Min.Name = "RB7_Min";
            this.RB7_Min.Size = new System.Drawing.Size(34, 21);
            this.RB7_Min.TabIndex = 21;
            this.RB7_Min.TabStop = true;
            this.RB7_Min.Text = "-";
            this.RB7_Min.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 134);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(115, 17);
            this.label11.TabIndex = 22;
            this.label11.Text = "Geef stapgrootte";
            // 
            // GB1
            // 
            this.GB1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GB1.Controls.Add(this.RB1_For);
            this.GB1.Controls.Add(this.RB2_While);
            this.GB1.Location = new System.Drawing.Point(36, 4);
            this.GB1.Name = "GB1";
            this.GB1.Size = new System.Drawing.Size(196, 163);
            this.GB1.TabIndex = 23;
            this.GB1.TabStop = false;
            this.GB1.Text = "1. Keuze For of While lus";
            // 
            // GB2
            // 
            this.GB2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GB2.Controls.Add(this.RB14);
            this.GB2.Controls.Add(this.TB1_Beginwaarde);
            this.GB2.Controls.Add(this.label6);
            this.GB2.Controls.Add(this.RB13);
            this.GB2.Controls.Add(this.label2);
            this.GB2.Controls.Add(this.label3);
            this.GB2.Controls.Add(this.RB11);
            this.GB2.Controls.Add(this.RB12);
            this.GB2.Controls.Add(this.RB10);
            this.GB2.Controls.Add(this.label4);
            this.GB2.Location = new System.Drawing.Point(238, 4);
            this.GB2.Name = "GB2";
            this.GB2.Size = new System.Drawing.Size(200, 163);
            this.GB2.TabIndex = 10;
            this.GB2.TabStop = false;
            this.GB2.Text = "2. Beginwaarde bepalen";
            // 
            // RB14
            // 
            this.RB14.AutoSize = true;
            this.RB14.Location = new System.Drawing.Point(87, 35);
            this.RB14.Name = "RB14";
            this.RB14.Size = new System.Drawing.Size(37, 21);
            this.RB14.TabIndex = 36;
            this.RB14.TabStop = true;
            this.RB14.Text = "=";
            this.RB14.UseVisualStyleBackColor = true;
            // 
            // RB13
            // 
            this.RB13.AutoSize = true;
            this.RB13.Location = new System.Drawing.Point(131, 92);
            this.RB13.Name = "RB13";
            this.RB13.Size = new System.Drawing.Size(45, 21);
            this.RB13.TabIndex = 35;
            this.RB13.TabStop = true;
            this.RB13.Text = "<=";
            this.RB13.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "Geijk aan";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 17);
            this.label3.TabIndex = 31;
            this.label3.Text = "Groter dan";
            // 
            // RB11
            // 
            this.RB11.AutoSize = true;
            this.RB11.Location = new System.Drawing.Point(130, 62);
            this.RB11.Name = "RB11";
            this.RB11.Size = new System.Drawing.Size(45, 21);
            this.RB11.TabIndex = 34;
            this.RB11.TabStop = true;
            this.RB11.Text = ">=";
            this.RB11.UseVisualStyleBackColor = true;
            // 
            // RB12
            // 
            this.RB12.AutoSize = true;
            this.RB12.Location = new System.Drawing.Point(88, 92);
            this.RB12.Name = "RB12";
            this.RB12.Size = new System.Drawing.Size(37, 21);
            this.RB12.TabIndex = 30;
            this.RB12.TabStop = true;
            this.RB12.Text = "<";
            this.RB12.UseVisualStyleBackColor = true;
            // 
            // RB10
            // 
            this.RB10.AutoSize = true;
            this.RB10.Location = new System.Drawing.Point(88, 62);
            this.RB10.Name = "RB10";
            this.RB10.Size = new System.Drawing.Size(37, 21);
            this.RB10.TabIndex = 29;
            this.RB10.TabStop = true;
            this.RB10.Text = ">";
            this.RB10.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 17);
            this.label4.TabIndex = 32;
            this.label4.Text = "Kleiner dan";
            // 
            // GB3
            // 
            this.GB3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GB3.Controls.Add(this.RB3);
            this.GB3.Controls.Add(this.RB2);
            this.GB3.Controls.Add(this.label1);
            this.GB3.Controls.Add(this.RB1);
            this.GB3.Controls.Add(this.label7);
            this.GB3.Controls.Add(this.label8);
            this.GB3.Controls.Add(this.RB4_Groter_dan);
            this.GB3.Controls.Add(this.RB5_Kleiner_dan);
            this.GB3.Controls.Add(this.label9);
            this.GB3.Controls.Add(this.TB2_Eindwaarde);
            this.GB3.Location = new System.Drawing.Point(444, 4);
            this.GB3.Name = "GB3";
            this.GB3.Size = new System.Drawing.Size(200, 163);
            this.GB3.TabIndex = 24;
            this.GB3.TabStop = false;
            this.GB3.Text = "3. Eindwaarde bepalen";
            // 
            // RB3
            // 
            this.RB3.AutoSize = true;
            this.RB3.Location = new System.Drawing.Point(90, 92);
            this.RB3.Name = "RB3";
            this.RB3.Size = new System.Drawing.Size(37, 21);
            this.RB3.TabIndex = 28;
            this.RB3.TabStop = true;
            this.RB3.Text = "=";
            this.RB3.UseVisualStyleBackColor = true;
            // 
            // RB2
            // 
            this.RB2.AutoSize = true;
            this.RB2.Location = new System.Drawing.Point(132, 60);
            this.RB2.Name = "RB2";
            this.RB2.Size = new System.Drawing.Size(45, 21);
            this.RB2.TabIndex = 27;
            this.RB2.TabStop = true;
            this.RB2.Text = "<=";
            this.RB2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "Geijk aan";
            // 
            // RB1
            // 
            this.RB1.AutoSize = true;
            this.RB1.Location = new System.Drawing.Point(132, 30);
            this.RB1.Name = "RB1";
            this.RB1.Size = new System.Drawing.Size(45, 21);
            this.RB1.TabIndex = 26;
            this.RB1.TabStop = true;
            this.RB1.Text = ">=";
            this.RB1.UseVisualStyleBackColor = true;
            // 
            // GB4
            // 
            this.GB4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GB4.Controls.Add(this.RB5);
            this.GB4.Controls.Add(this.RB4);
            this.GB4.Controls.Add(this.label10);
            this.GB4.Controls.Add(this.RB6_Plus);
            this.GB4.Controls.Add(this.RB7_Min);
            this.GB4.Controls.Add(this.label11);
            this.GB4.Controls.Add(this.TB3_Stapgrootte);
            this.GB4.Location = new System.Drawing.Point(650, 4);
            this.GB4.Name = "GB4";
            this.GB4.Size = new System.Drawing.Size(200, 163);
            this.GB4.TabIndex = 25;
            this.GB4.TabStop = false;
            this.GB4.Text = "4. Stapgrootte bepalen";
            // 
            // RB5
            // 
            this.RB5.AutoSize = true;
            this.RB5.Location = new System.Drawing.Point(143, 60);
            this.RB5.Name = "RB5";
            this.RB5.Size = new System.Drawing.Size(33, 21);
            this.RB5.TabIndex = 26;
            this.RB5.TabStop = true;
            this.RB5.Text = "/";
            this.RB5.UseVisualStyleBackColor = true;
            // 
            // RB4
            // 
            this.RB4.AutoSize = true;
            this.RB4.Location = new System.Drawing.Point(143, 33);
            this.RB4.Name = "RB4";
            this.RB4.Size = new System.Drawing.Size(34, 21);
            this.RB4.TabIndex = 23;
            this.RB4.TabStop = true;
            this.RB4.Text = "*";
            this.RB4.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(911, 547);
            this.Controls.Add(this.GB4);
            this.Controls.Add(this.GB3);
            this.Controls.Add(this.GB2);
            this.Controls.Add(this.GB1);
            this.Controls.Add(this.LB1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.GB1.ResumeLayout(false);
            this.GB1.PerformLayout();
            this.GB2.ResumeLayout(false);
            this.GB2.PerformLayout();
            this.GB3.ResumeLayout(false);
            this.GB3.PerformLayout();
            this.GB4.ResumeLayout(false);
            this.GB4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox LB1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton RB1_For;
        private System.Windows.Forms.RadioButton RB2_While;
        private System.Windows.Forms.TextBox TB1_Beginwaarde;
        private System.Windows.Forms.RadioButton RB4_Groter_dan;
        private System.Windows.Forms.RadioButton RB5_Kleiner_dan;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TB2_Eindwaarde;
        private System.Windows.Forms.TextBox TB3_Stapgrootte;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton RB6_Plus;
        private System.Windows.Forms.RadioButton RB7_Min;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox GB1;
        private System.Windows.Forms.GroupBox GB2;
        private System.Windows.Forms.GroupBox GB3;
        private System.Windows.Forms.GroupBox GB4;
        private System.Windows.Forms.RadioButton RB2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton RB1;
        private System.Windows.Forms.RadioButton RB3;
        private System.Windows.Forms.RadioButton RB4;
        private System.Windows.Forms.RadioButton RB5;
        private System.Windows.Forms.RadioButton RB14;
        private System.Windows.Forms.RadioButton RB13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton RB11;
        private System.Windows.Forms.RadioButton RB12;
        private System.Windows.Forms.RadioButton RB10;
        private System.Windows.Forms.Label label4;
    }
}

