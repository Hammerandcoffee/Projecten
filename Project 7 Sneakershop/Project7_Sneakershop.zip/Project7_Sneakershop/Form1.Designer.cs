﻿
namespace Project7_Sneakershop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sneakerbox = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Aantalklompen = new System.Windows.Forms.TextBox();
            this.Aantalbanana = new System.Windows.Forms.TextBox();
            this.Aantaldrip = new System.Windows.Forms.TextBox();
            this.Aantaljordens = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Prijsklompen = new System.Windows.Forms.TextBox();
            this.Prijsbanana = new System.Windows.Forms.TextBox();
            this.Prijsdrips = new System.Windows.Forms.TextBox();
            this.Prijsjordens = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Schoen4 = new System.Windows.Forms.CheckBox();
            this.Schoen3 = new System.Windows.Forms.CheckBox();
            this.Schoen2 = new System.Windows.Forms.CheckBox();
            this.Schoen1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Kosten = new System.Windows.Forms.GroupBox();
            this.Totaalkosten = new System.Windows.Forms.TextBox();
            this.Verzendkosten = new System.Windows.Forms.TextBox();
            this.B1 = new System.Windows.Forms.Button();
            this.WelBTWkosten = new System.Windows.Forms.TextBox();
            this.GeenBTWkosten = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.Aantalbullit = new System.Windows.Forms.TextBox();
            this.Aantalbull = new System.Windows.Forms.TextBox();
            this.AantalSpa = new System.Windows.Forms.TextBox();
            this.Aantalmonster = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.Prijsbullit = new System.Windows.Forms.TextBox();
            this.Prijsredbull = new System.Windows.Forms.TextBox();
            this.Prijsspaextreme = new System.Windows.Forms.TextBox();
            this.PrijsMonster = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.Drink4 = new System.Windows.Forms.CheckBox();
            this.Drink3 = new System.Windows.Forms.CheckBox();
            this.Drink2 = new System.Windows.Forms.CheckBox();
            this.Drink1 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Pbgroot2 = new System.Windows.Forms.PictureBox();
            this.Pbgroot = new System.Windows.Forms.PictureBox();
            this.Sneakerbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Kosten.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbgroot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbgroot)).BeginInit();
            this.SuspendLayout();
            // 
            // Sneakerbox
            // 
            this.Sneakerbox.Controls.Add(this.pictureBox4);
            this.Sneakerbox.Controls.Add(this.pictureBox3);
            this.Sneakerbox.Controls.Add(this.pictureBox2);
            this.Sneakerbox.Controls.Add(this.pictureBox1);
            this.Sneakerbox.Controls.Add(this.Aantalklompen);
            this.Sneakerbox.Controls.Add(this.Aantalbanana);
            this.Sneakerbox.Controls.Add(this.Aantaldrip);
            this.Sneakerbox.Controls.Add(this.Aantaljordens);
            this.Sneakerbox.Controls.Add(this.label12);
            this.Sneakerbox.Controls.Add(this.label11);
            this.Sneakerbox.Controls.Add(this.label10);
            this.Sneakerbox.Controls.Add(this.label9);
            this.Sneakerbox.Controls.Add(this.label8);
            this.Sneakerbox.Controls.Add(this.label7);
            this.Sneakerbox.Controls.Add(this.label6);
            this.Sneakerbox.Controls.Add(this.Prijsklompen);
            this.Sneakerbox.Controls.Add(this.Prijsbanana);
            this.Sneakerbox.Controls.Add(this.Prijsdrips);
            this.Sneakerbox.Controls.Add(this.Prijsjordens);
            this.Sneakerbox.Controls.Add(this.label5);
            this.Sneakerbox.Controls.Add(this.label4);
            this.Sneakerbox.Controls.Add(this.label3);
            this.Sneakerbox.Controls.Add(this.Schoen4);
            this.Sneakerbox.Controls.Add(this.Schoen3);
            this.Sneakerbox.Controls.Add(this.Schoen2);
            this.Sneakerbox.Controls.Add(this.Schoen1);
            this.Sneakerbox.Controls.Add(this.label1);
            this.Sneakerbox.Controls.Add(this.label2);
            this.Sneakerbox.Location = new System.Drawing.Point(23, 4);
            this.Sneakerbox.Name = "Sneakerbox";
            this.Sneakerbox.Size = new System.Drawing.Size(400, 291);
            this.Sneakerbox.TabIndex = 0;
            this.Sneakerbox.TabStop = false;
            this.Sneakerbox.Text = "Sneakers";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Project7_Sneakershop.Properties.Resources.Drip;
            this.pictureBox4.Location = new System.Drawing.Point(324, 114);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 46);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 29;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Project7_Sneakershop.Properties.Resources.Banana;
            this.pictureBox3.Location = new System.Drawing.Point(324, 166);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 46);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Project7_Sneakershop.Properties.Resources.proxy_image;
            this.pictureBox2.Location = new System.Drawing.Point(324, 218);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(52, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = global::Project7_Sneakershop.Properties.Resources.Jordens;
            this.pictureBox1.Image = global::Project7_Sneakershop.Properties.Resources.Jordens;
            this.pictureBox1.Location = new System.Drawing.Point(324, 57);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(54, 51);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Aantalklompen
            // 
            this.Aantalklompen.Location = new System.Drawing.Point(260, 242);
            this.Aantalklompen.Name = "Aantalklompen";
            this.Aantalklompen.Size = new System.Drawing.Size(58, 22);
            this.Aantalklompen.TabIndex = 26;
            // 
            // Aantalbanana
            // 
            this.Aantalbanana.Location = new System.Drawing.Point(260, 182);
            this.Aantalbanana.Name = "Aantalbanana";
            this.Aantalbanana.Size = new System.Drawing.Size(58, 22);
            this.Aantalbanana.TabIndex = 25;
            // 
            // Aantaldrip
            // 
            this.Aantaldrip.Location = new System.Drawing.Point(260, 119);
            this.Aantaldrip.Name = "Aantaldrip";
            this.Aantaldrip.Size = new System.Drawing.Size(58, 22);
            this.Aantaldrip.TabIndex = 24;
            // 
            // Aantaljordens
            // 
            this.Aantaljordens.Location = new System.Drawing.Point(260, 61);
            this.Aantaljordens.Name = "Aantaljordens";
            this.Aantaljordens.Size = new System.Drawing.Size(58, 22);
            this.Aantaljordens.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(206, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 17);
            this.label12.TabIndex = 22;
            this.label12.Text = "Aantal";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(206, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 17);
            this.label11.TabIndex = 21;
            this.label11.Text = "Aantal";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(206, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 17);
            this.label10.TabIndex = 20;
            this.label10.Text = "Aantal";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(206, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "Aantal";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "The Drip";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "The Banana";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "The Klomps";
            // 
            // Prijsklompen
            // 
            this.Prijsklompen.Location = new System.Drawing.Point(144, 237);
            this.Prijsklompen.Name = "Prijsklompen";
            this.Prijsklompen.ReadOnly = true;
            this.Prijsklompen.Size = new System.Drawing.Size(56, 22);
            this.Prijsklompen.TabIndex = 16;
            this.Prijsklompen.Text = "$110";
            // 
            // Prijsbanana
            // 
            this.Prijsbanana.Location = new System.Drawing.Point(144, 177);
            this.Prijsbanana.Name = "Prijsbanana";
            this.Prijsbanana.ReadOnly = true;
            this.Prijsbanana.Size = new System.Drawing.Size(56, 22);
            this.Prijsbanana.TabIndex = 15;
            this.Prijsbanana.Text = "$50";
            // 
            // Prijsdrips
            // 
            this.Prijsdrips.Location = new System.Drawing.Point(144, 114);
            this.Prijsdrips.Name = "Prijsdrips";
            this.Prijsdrips.ReadOnly = true;
            this.Prijsdrips.Size = new System.Drawing.Size(56, 22);
            this.Prijsdrips.TabIndex = 14;
            this.Prijsdrips.Text = "$80";
            // 
            // Prijsjordens
            // 
            this.Prijsjordens.Location = new System.Drawing.Point(144, 58);
            this.Prijsjordens.Name = "Prijsjordens";
            this.Prijsjordens.ReadOnly = true;
            this.Prijsjordens.Size = new System.Drawing.Size(56, 22);
            this.Prijsjordens.TabIndex = 13;
            this.Prijsjordens.Text = "$60";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Prijs (excl BTW)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Prijs (excl BTW)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Prijs (excl BTW)";
            // 
            // Schoen4
            // 
            this.Schoen4.AutoSize = true;
            this.Schoen4.Location = new System.Drawing.Point(6, 235);
            this.Schoen4.Name = "Schoen4";
            this.Schoen4.Size = new System.Drawing.Size(18, 17);
            this.Schoen4.TabIndex = 3;
            this.Schoen4.UseVisualStyleBackColor = true;
            // 
            // Schoen3
            // 
            this.Schoen3.AutoSize = true;
            this.Schoen3.Location = new System.Drawing.Point(6, 177);
            this.Schoen3.Name = "Schoen3";
            this.Schoen3.Size = new System.Drawing.Size(18, 17);
            this.Schoen3.TabIndex = 2;
            this.Schoen3.UseVisualStyleBackColor = true;
            // 
            // Schoen2
            // 
            this.Schoen2.AutoSize = true;
            this.Schoen2.Location = new System.Drawing.Point(6, 114);
            this.Schoen2.Name = "Schoen2";
            this.Schoen2.Size = new System.Drawing.Size(18, 17);
            this.Schoen2.TabIndex = 1;
            this.Schoen2.UseVisualStyleBackColor = true;
            // 
            // Schoen1
            // 
            this.Schoen1.AutoSize = true;
            this.Schoen1.Location = new System.Drawing.Point(6, 58);
            this.Schoen1.Name = "Schoen1";
            this.Schoen1.Size = new System.Drawing.Size(18, 17);
            this.Schoen1.TabIndex = 0;
            this.Schoen1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "The Jordens";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Prijs (excl BTW)";
            // 
            // Kosten
            // 
            this.Kosten.Controls.Add(this.Totaalkosten);
            this.Kosten.Controls.Add(this.Verzendkosten);
            this.Kosten.Controls.Add(this.B1);
            this.Kosten.Controls.Add(this.WelBTWkosten);
            this.Kosten.Controls.Add(this.GeenBTWkosten);
            this.Kosten.Controls.Add(this.label28);
            this.Kosten.Controls.Add(this.label27);
            this.Kosten.Controls.Add(this.label26);
            this.Kosten.Controls.Add(this.label25);
            this.Kosten.Location = new System.Drawing.Point(283, 310);
            this.Kosten.Name = "Kosten";
            this.Kosten.Size = new System.Drawing.Size(300, 272);
            this.Kosten.TabIndex = 1;
            this.Kosten.TabStop = false;
            this.Kosten.Text = "Totale kosten";
            // 
            // Totaalkosten
            // 
            this.Totaalkosten.Location = new System.Drawing.Point(172, 147);
            this.Totaalkosten.Name = "Totaalkosten";
            this.Totaalkosten.ReadOnly = true;
            this.Totaalkosten.Size = new System.Drawing.Size(100, 22);
            this.Totaalkosten.TabIndex = 41;
            // 
            // Verzendkosten
            // 
            this.Verzendkosten.Location = new System.Drawing.Point(172, 108);
            this.Verzendkosten.Name = "Verzendkosten";
            this.Verzendkosten.ReadOnly = true;
            this.Verzendkosten.Size = new System.Drawing.Size(100, 22);
            this.Verzendkosten.TabIndex = 40;
            // 
            // B1
            // 
            this.B1.Location = new System.Drawing.Point(45, 190);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(199, 74);
            this.B1.TabIndex = 42;
            this.B1.Text = "Berekenen";
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // WelBTWkosten
            // 
            this.WelBTWkosten.Location = new System.Drawing.Point(172, 73);
            this.WelBTWkosten.Name = "WelBTWkosten";
            this.WelBTWkosten.ReadOnly = true;
            this.WelBTWkosten.Size = new System.Drawing.Size(100, 22);
            this.WelBTWkosten.TabIndex = 39;
            // 
            // GeenBTWkosten
            // 
            this.GeenBTWkosten.Location = new System.Drawing.Point(172, 36);
            this.GeenBTWkosten.Name = "GeenBTWkosten";
            this.GeenBTWkosten.ReadOnly = true;
            this.GeenBTWkosten.Size = new System.Drawing.Size(100, 22);
            this.GeenBTWkosten.TabIndex = 38;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(15, 150);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(94, 17);
            this.label28.TabIndex = 37;
            this.label28.Text = "Totale kosten";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(15, 108);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 17);
            this.label27.TabIndex = 36;
            this.label27.Text = "Verzendkosten";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 73);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(150, 17);
            this.label26.TabIndex = 35;
            this.label26.Text = "Kosten inclusief BTW :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 39);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(123, 17);
            this.label25.TabIndex = 34;
            this.label25.Text = "Kosten excl BTW :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.Aantalbullit);
            this.groupBox1.Controls.Add(this.Aantalbull);
            this.groupBox1.Controls.Add(this.AantalSpa);
            this.groupBox1.Controls.Add(this.Aantalmonster);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.Prijsbullit);
            this.groupBox1.Controls.Add(this.Prijsredbull);
            this.groupBox1.Controls.Add(this.Prijsspaextreme);
            this.groupBox1.Controls.Add(this.PrijsMonster);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.Drink4);
            this.groupBox1.Controls.Add(this.Drink3);
            this.groupBox1.Controls.Add(this.Drink2);
            this.groupBox1.Controls.Add(this.Drink1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Location = new System.Drawing.Point(429, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 291);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Energydrinks";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Project7_Sneakershop.Properties.Resources.Bullit;
            this.pictureBox5.Location = new System.Drawing.Point(324, 218);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(52, 46);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 30;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Project7_Sneakershop.Properties.Resources.Redbull;
            this.pictureBox6.Location = new System.Drawing.Point(324, 166);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(52, 46);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 31;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Project7_Sneakershop.Properties.Resources.Spa;
            this.pictureBox7.Location = new System.Drawing.Point(324, 114);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(52, 46);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 32;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Project7_Sneakershop.Properties.Resources.Monster;
            this.pictureBox8.Location = new System.Drawing.Point(324, 57);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(52, 46);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 33;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // Aantalbullit
            // 
            this.Aantalbullit.Location = new System.Drawing.Point(260, 242);
            this.Aantalbullit.Name = "Aantalbullit";
            this.Aantalbullit.Size = new System.Drawing.Size(58, 22);
            this.Aantalbullit.TabIndex = 26;
            // 
            // Aantalbull
            // 
            this.Aantalbull.Location = new System.Drawing.Point(260, 182);
            this.Aantalbull.Name = "Aantalbull";
            this.Aantalbull.Size = new System.Drawing.Size(58, 22);
            this.Aantalbull.TabIndex = 25;
            // 
            // AantalSpa
            // 
            this.AantalSpa.Location = new System.Drawing.Point(260, 119);
            this.AantalSpa.Name = "AantalSpa";
            this.AantalSpa.Size = new System.Drawing.Size(58, 22);
            this.AantalSpa.TabIndex = 24;
            // 
            // Aantalmonster
            // 
            this.Aantalmonster.Location = new System.Drawing.Point(260, 61);
            this.Aantalmonster.Name = "Aantalmonster";
            this.Aantalmonster.Size = new System.Drawing.Size(58, 22);
            this.Aantalmonster.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(206, 119);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 17);
            this.label13.TabIndex = 22;
            this.label13.Text = "Aantal";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(206, 182);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 17);
            this.label14.TabIndex = 21;
            this.label14.Text = "Aantal";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(206, 242);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 17);
            this.label15.TabIndex = 20;
            this.label15.Text = "Aantal";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(206, 61);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 17);
            this.label16.TabIndex = 8;
            this.label16.Text = "Aantal";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(25, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(143, 17);
            this.label17.TabIndex = 19;
            this.label17.Text = "Spa extreme (500 ml)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(25, 159);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(116, 17);
            this.label18.TabIndex = 18;
            this.label18.Text = "Red bull (250 ml)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(23, 215);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 17);
            this.label19.TabIndex = 17;
            this.label19.Text = "Bullit (500 ml)";
            // 
            // Prijsbullit
            // 
            this.Prijsbullit.Location = new System.Drawing.Point(144, 237);
            this.Prijsbullit.Name = "Prijsbullit";
            this.Prijsbullit.ReadOnly = true;
            this.Prijsbullit.Size = new System.Drawing.Size(56, 22);
            this.Prijsbullit.TabIndex = 16;
            this.Prijsbullit.Text = "$3";
            // 
            // Prijsredbull
            // 
            this.Prijsredbull.Location = new System.Drawing.Point(144, 177);
            this.Prijsredbull.Name = "Prijsredbull";
            this.Prijsredbull.ReadOnly = true;
            this.Prijsredbull.Size = new System.Drawing.Size(56, 22);
            this.Prijsredbull.TabIndex = 15;
            this.Prijsredbull.Text = "$1,25";
            // 
            // Prijsspaextreme
            // 
            this.Prijsspaextreme.Location = new System.Drawing.Point(144, 114);
            this.Prijsspaextreme.Name = "Prijsspaextreme";
            this.Prijsspaextreme.ReadOnly = true;
            this.Prijsspaextreme.Size = new System.Drawing.Size(56, 22);
            this.Prijsspaextreme.TabIndex = 14;
            this.Prijsspaextreme.Text = "$2";
            // 
            // PrijsMonster
            // 
            this.PrijsMonster.Location = new System.Drawing.Point(144, 58);
            this.PrijsMonster.Name = "PrijsMonster";
            this.PrijsMonster.ReadOnly = true;
            this.PrijsMonster.Size = new System.Drawing.Size(56, 22);
            this.PrijsMonster.TabIndex = 13;
            this.PrijsMonster.Text = "$1,50";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(30, 237);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(108, 17);
            this.label20.TabIndex = 12;
            this.label20.Text = "Prijs (excl BTW)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(30, 116);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(108, 17);
            this.label21.TabIndex = 11;
            this.label21.Text = "Prijs (excl BTW)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(30, 176);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(108, 17);
            this.label22.TabIndex = 10;
            this.label22.Text = "Prijs (excl BTW)";
            // 
            // Drink4
            // 
            this.Drink4.AutoSize = true;
            this.Drink4.Location = new System.Drawing.Point(6, 235);
            this.Drink4.Name = "Drink4";
            this.Drink4.Size = new System.Drawing.Size(18, 17);
            this.Drink4.TabIndex = 3;
            this.Drink4.UseVisualStyleBackColor = true;
            // 
            // Drink3
            // 
            this.Drink3.AutoSize = true;
            this.Drink3.Location = new System.Drawing.Point(6, 177);
            this.Drink3.Name = "Drink3";
            this.Drink3.Size = new System.Drawing.Size(18, 17);
            this.Drink3.TabIndex = 2;
            this.Drink3.UseVisualStyleBackColor = true;
            // 
            // Drink2
            // 
            this.Drink2.AutoSize = true;
            this.Drink2.Location = new System.Drawing.Point(6, 114);
            this.Drink2.Name = "Drink2";
            this.Drink2.Size = new System.Drawing.Size(18, 17);
            this.Drink2.TabIndex = 1;
            this.Drink2.UseVisualStyleBackColor = true;
            // 
            // Drink1
            // 
            this.Drink1.AutoSize = true;
            this.Drink1.Location = new System.Drawing.Point(6, 58);
            this.Drink1.Name = "Drink1";
            this.Drink1.Size = new System.Drawing.Size(18, 17);
            this.Drink1.TabIndex = 0;
            this.Drink1.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(25, 33);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(115, 17);
            this.label23.TabIndex = 8;
            this.label23.Text = "Monster (500 ml)";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(30, 57);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(108, 17);
            this.label24.TabIndex = 9;
            this.label24.Text = "Prijs (excl BTW)";
            // 
            // Pbgroot2
            // 
            this.Pbgroot2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.Pbgroot2.Image = global::Project7_Sneakershop.Properties.Resources.Monster;
            this.Pbgroot2.Location = new System.Drawing.Point(589, 310);
            this.Pbgroot2.Name = "Pbgroot2";
            this.Pbgroot2.Size = new System.Drawing.Size(240, 195);
            this.Pbgroot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Pbgroot2.TabIndex = 44;
            this.Pbgroot2.TabStop = false;
            this.Pbgroot2.UseWaitCursor = true;
            // 
            // Pbgroot
            // 
            this.Pbgroot.Image = global::Project7_Sneakershop.Properties.Resources.Jordens;
            this.Pbgroot.Location = new System.Drawing.Point(23, 316);
            this.Pbgroot.Name = "Pbgroot";
            this.Pbgroot.Size = new System.Drawing.Size(254, 189);
            this.Pbgroot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Pbgroot.TabIndex = 43;
            this.Pbgroot.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 712);
            this.Controls.Add(this.Pbgroot2);
            this.Controls.Add(this.Pbgroot);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Kosten);
            this.Controls.Add(this.Sneakerbox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Sneakerbox.ResumeLayout(false);
            this.Sneakerbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Kosten.ResumeLayout(false);
            this.Kosten.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbgroot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pbgroot)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Sneakerbox;
        private System.Windows.Forms.GroupBox Kosten;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Aantalklompen;
        private System.Windows.Forms.TextBox Aantalbanana;
        private System.Windows.Forms.TextBox Aantaldrip;
        private System.Windows.Forms.TextBox Aantaljordens;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Prijsklompen;
        private System.Windows.Forms.TextBox Prijsbanana;
        private System.Windows.Forms.TextBox Prijsdrips;
        private System.Windows.Forms.TextBox Prijsjordens;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox Schoen4;
        private System.Windows.Forms.CheckBox Schoen3;
        private System.Windows.Forms.CheckBox Schoen2;
        private System.Windows.Forms.CheckBox Schoen1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Totaalkosten;
        private System.Windows.Forms.TextBox Verzendkosten;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.TextBox WelBTWkosten;
        private System.Windows.Forms.TextBox GeenBTWkosten;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.TextBox Aantalbullit;
        private System.Windows.Forms.TextBox Aantalbull;
        private System.Windows.Forms.TextBox AantalSpa;
        private System.Windows.Forms.TextBox Aantalmonster;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox Prijsbullit;
        private System.Windows.Forms.TextBox Prijsredbull;
        private System.Windows.Forms.TextBox Prijsspaextreme;
        private System.Windows.Forms.TextBox PrijsMonster;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox Drink4;
        private System.Windows.Forms.CheckBox Drink3;
        private System.Windows.Forms.CheckBox Drink2;
        private System.Windows.Forms.CheckBox Drink1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox Pbgroot;
        private System.Windows.Forms.PictureBox Pbgroot2;
    }
}

