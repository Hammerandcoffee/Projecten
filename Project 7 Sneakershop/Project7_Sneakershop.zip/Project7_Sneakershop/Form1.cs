﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7_Sneakershop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void B1_Click(object sender, EventArgs e)
        {
            try
            {
                double finalmetBTW = 0;
                double finalzonderBTW = 0;
                double verzendkosten = 0;
                double totaal = 0;


                if (Schoen1.Checked)
                {
                    double Prijsjorden = 60;
                    double Jordensaantal = double.Parse(Aantaljordens.Text);

                    double Jordenfinal = BTWhoog(Prijsjorden, Jordensaantal);
                    finalmetBTW += Jordenfinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Jordenfinal2 = geenBTW(Prijsjorden, Jordensaantal);
                    finalzonderBTW += Jordenfinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 4;
                    Verzendkosten.Text = verzendkosten.ToString();

                }
                if (Schoen2.Checked)
                {
                    double Prijsdrip = 80;
                    double Dripaantal = double.Parse(Aantaldrip.Text);

                    double Dripfinal = BTWhoog(Prijsdrip, Dripaantal);
                    finalmetBTW += Dripfinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Dripfinal2 = geenBTW(Prijsdrip, Dripaantal);
                    finalzonderBTW += Dripfinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 4;
                    Verzendkosten.Text = verzendkosten.ToString();
                }
                if (Schoen3.Checked)
                {
                    double Prijsbana = 50;
                    double Banaaantal = double.Parse(Aantalbanana.Text);

                    double Banafinal = BTWhoog(Prijsbana, Banaaantal);
                    finalmetBTW += Banafinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Banafinal2 = geenBTW(Prijsbana, Banaaantal);
                    finalzonderBTW += Banafinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 4;
                    Verzendkosten.Text = verzendkosten.ToString();
                }
                if (Schoen4.Checked)
                {
                    double Prijsklomps = 110;
                    double Klompaantal = double.Parse(Aantalklompen.Text);

                    double Klompfinal = BTWhoog(Prijsklomps, Klompaantal);
                    finalmetBTW += Klompfinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Klompfinal2 = geenBTW(Prijsklomps, Klompaantal);
                    finalzonderBTW += Klompfinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 4;
                    Verzendkosten.Text = verzendkosten.ToString();

                }
                if (Drink1.Checked)
                {
                    double Prijsmonster = 1.50;
                    double Monsteraantal = double.Parse(Aantalmonster.Text);

                    double Monsterfinal = BTWlaag(Prijsmonster, Monsteraantal);
                    finalmetBTW += Monsterfinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Monsterfinal2 = geenBTW(Prijsmonster, Monsteraantal);
                    finalzonderBTW += Monsterfinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 2;
                    Verzendkosten.Text = verzendkosten.ToString();

                }
                if (Drink2.Checked)
                {
                    double Prijsspa = 2;
                    double Spaaantal = double.Parse(AantalSpa.Text);

                    double Spafinal = BTWlaag(Prijsspa, Spaaantal);
                    finalmetBTW += Spafinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Spafinal2 = geenBTW(Prijsspa, Spaaantal);
                    finalzonderBTW += Spafinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 2;
                    Verzendkosten.Text = verzendkosten.ToString();
                }
                if (Drink3.Checked)
                {
                    double Prijsred = 1.25;
                    double Redaantal = double.Parse(Aantalbull.Text);

                    double Redfinal = BTWlaag(Prijsred, Redaantal);
                    finalmetBTW += Redfinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Redfinal2 = geenBTW(Prijsred, Redaantal);
                    finalzonderBTW += Redfinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 2;
                    Verzendkosten.Text = verzendkosten.ToString();
                }
                if (Drink4.Checked)
                {
                    double Prijsbul = 3;
                    double Bullaantal = double.Parse(Aantalbullit.Text);

                    double Bulfinal = BTWlaag(Prijsbul, Bullaantal);
                    finalmetBTW += Bulfinal;
                    WelBTWkosten.Text = finalmetBTW.ToString();

                    double Bulfinal2 = geenBTW(Prijsbul, Bullaantal);
                    finalzonderBTW += Bulfinal2;
                    GeenBTWkosten.Text = finalzonderBTW.ToString();

                    verzendkosten += 2;
                    Verzendkosten.Text = verzendkosten.ToString();

                }
                totaal += finalmetBTW += verzendkosten;
                Totaalkosten.Text = totaal.ToString();

                double BTWlaag(double a, double b)
                {
                    double oplossing = a * b;
                    double Final;
                    {
                        return oplossing / 100 * 9 + oplossing;

                    }
                }

                double BTWhoog(double c, double d)
                {
                    double oplossing = c * d;
                    double Final;
                    {
                        return oplossing / 100 * 21 + oplossing;

                    }
                }
                double geenBTW(double f, double g)
                {
                    double oplossing = f * g;
                    double Final;
                    {
                        return oplossing;

                    }
                }
            }
            catch
            {
                MessageBox.Show("Voer een aantal in");
            }
         
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var picture = (PictureBox)sender;
            Pbgroot.Image = picture.Image;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            var picture = (PictureBox)sender;
            Pbgroot2.Image = picture.Image;
        }
    }
}
