﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tamagotchi_StefanSeverijnen
{
    public partial class Form1 : Form
    {
        private int welzijnInt = 100;
        private int etenInt = 100;
        private int drinkenInt = 100;
        private int scoreInt = 0;
        private int tijd = 0;
        private int etengeven = 60;
        private int drinkengeven = 40;
        private bool drinkenwelzijnsneller = false;
        private bool drinkenwelzijnsneller2 = false;
        private bool etenwelzijnsneller = false;
        private bool etenwelzijnsneller2 = false;
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PB1.Image = Properties.Resources.mrcannyhappy;
            Welzijntimer.Start();
            Etentimer.Start();
            Drinkentimer.Start();
            Scoretimer.Start();
            mrcanny.Start();
            Timer.Start();
        }

        private void Welzijntimer_Tick(object sender, EventArgs e)
        {
            try
            {
                welzijnbar.Value = welzijnInt;
                if (etenInt >= 85 && drinkenInt >= 80)
                {
                    welzijnInt++;
                    if (welzijnInt > 100)
                        welzijnInt = 100;
                    welzijnbar.Value = welzijnInt;
                }
                else
                {
                    welzijnInt--;
                }
             
            }
            catch
            {
                Welzijntimer.Stop();
                Etentimer.Stop();
                Drinkentimer.Stop();
                Scoretimer.Stop();
                Timer.Stop();
                int Eindscore = scoreInt * tijd;
                MessageBox.Show($"je eindscore is {Eindscore}");
                this.Close();
            }

        }

        private void Etentimer_Tick(object sender, EventArgs e)
        {
            etenbar.Value = etenInt;
            etenInt--;

            if (etenInt == 0)
            {
                welzijnInt -= 30;
            }
            else if (etenInt == -1)
            {
                Etentimer.Stop();
                geefeten.Enabled = false;
            }
            else if (etenInt <= 40 && !etenwelzijnsneller2)
            {
                Welzijntimer.Interval -= 200;
                etenwelzijnsneller2 = true;
            }
            else if (etenInt <= 60 && !etenwelzijnsneller)
            {
                Welzijntimer.Interval -= 250;
                etenwelzijnsneller = true;
            }

        }

        private void Drinkentimer_Tick(object sender, EventArgs e)
        {
            drinkenbar.Value = drinkenInt;
            drinkenInt--;
            if (drinkenInt == 0)
            {
                welzijnInt -= 25;
            }
            else if (drinkenInt == -1)
            {
                Drinkentimer.Stop();
                geefdrinken.Enabled = false;
            }
            else if (drinkenInt <= 45 && !drinkenwelzijnsneller2)
            {
                Welzijntimer.Interval -= 150;
                drinkenwelzijnsneller2 = true;
            }
            else if (drinkenInt <= 65 && !drinkenwelzijnsneller)
            {
                Welzijntimer.Interval -= 200;
                drinkenwelzijnsneller = true;
            }
        }

        private void Scoretimer_Tick(object sender, EventArgs e)
        {
            if (welzijnInt < 50)
            {
                scoreInt += 25;
                Score.Text = scoreInt.ToString();
            }
            else if (scoreInt > -1)
            {
                scoreInt += 15;
                Score.Text = scoreInt.ToString();
            }
        }

        private void mrcanny_Tick(object sender, EventArgs e)
        {
            if (welzijnInt > 75)
            {
                PB1.Image = Properties.Resources.mrcannyhappy;
                PB1.Refresh();
            }
            else if (welzijnInt == -1)
            {
                PB1.Image = Properties.Resources.mrcannydead;
                PB1.Refresh();
            }
            else if (welzijnInt < 25)
            {
                PB1.Image = Properties.Resources.mrcannylastbreath;
                PB1.Refresh();
            }
            else if (welzijnInt < 45)
            {
                PB1.Image = Properties.Resources.mrcannydying;
                PB1.Refresh();
            }
            else if (welzijnInt < 75)
            {
                PB1.Image = Properties.Resources.mrcannysad;
                PB1.Refresh();
            }
        }

        private void geefeten_Click(object sender, EventArgs e)
        {
            if (scoreInt >= etengeven)
            {
                etenInt += 20;
                if (etenInt > 100)
                {
                    etenInt = 100;
                    
                }

                scoreInt -= etengeven;
                etenbar.Value = etenInt;
                Score.Text = scoreInt.ToString();
                etengeven += 20;
                Prijseten.Text = $"Prijs ${etengeven}";
            }
        }

        private void geefdrinken_Click(object sender, EventArgs e)
        {
            if (scoreInt >= drinkengeven)
            {
                drinkenInt += 15;
                if (drinkenInt > 100)
                {
                    drinkenInt = 100;
                }

                scoreInt -= drinkengeven;
                drinkenbar.Value = drinkenInt;
                Score.Text = scoreInt.ToString();
                drinkengeven += 15;
                Prijswater.Text = $"Prijs ${drinkengeven}";
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            tijd++;
            Tijd.Text = tijd.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
