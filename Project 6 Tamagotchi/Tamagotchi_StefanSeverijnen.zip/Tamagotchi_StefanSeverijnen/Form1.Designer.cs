﻿
namespace Tamagotchi_StefanSeverijnen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PB1 = new System.Windows.Forms.PictureBox();
            this.geefeten = new System.Windows.Forms.Button();
            this.geefdrinken = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Score = new System.Windows.Forms.TextBox();
            this.Welzijntimer = new System.Windows.Forms.Timer(this.components);
            this.Etentimer = new System.Windows.Forms.Timer(this.components);
            this.Drinkentimer = new System.Windows.Forms.Timer(this.components);
            this.Scoretimer = new System.Windows.Forms.Timer(this.components);
            this.mrcanny = new System.Windows.Forms.Timer(this.components);
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.Tijd = new System.Windows.Forms.TextBox();
            this.perish = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Prijseten = new System.Windows.Forms.Label();
            this.Prijswater = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.drinkenbar = new Tamagotchi_StefanSeverijnen.CustomProgressBar();
            this.etenbar = new Tamagotchi_StefanSeverijnen.CustomProgressBar();
            this.welzijnbar = new Tamagotchi_StefanSeverijnen.CustomProgressBar();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).BeginInit();
            this.SuspendLayout();
            // 
            // PB1
            // 
            this.PB1.ErrorImage = global::Tamagotchi_StefanSeverijnen.Properties.Resources.mrcannylastbreath;
            this.PB1.Location = new System.Drawing.Point(31, 44);
            this.PB1.Name = "PB1";
            this.PB1.Size = new System.Drawing.Size(322, 346);
            this.PB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PB1.TabIndex = 3;
            this.PB1.TabStop = false;
            // 
            // geefeten
            // 
            this.geefeten.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.geefeten.Location = new System.Drawing.Point(403, 209);
            this.geefeten.Name = "geefeten";
            this.geefeten.Size = new System.Drawing.Size(156, 108);
            this.geefeten.TabIndex = 4;
            this.geefeten.Text = "Geef eten";
            this.geefeten.UseVisualStyleBackColor = false;
            this.geefeten.Click += new System.EventHandler(this.geefeten_Click);
            // 
            // geefdrinken
            // 
            this.geefdrinken.BackColor = System.Drawing.Color.RoyalBlue;
            this.geefdrinken.Location = new System.Drawing.Point(565, 209);
            this.geefdrinken.Name = "geefdrinken";
            this.geefdrinken.Size = new System.Drawing.Size(156, 108);
            this.geefdrinken.TabIndex = 5;
            this.geefdrinken.Text = "Geef drinken";
            this.geefdrinken.UseVisualStyleBackColor = false;
            this.geefdrinken.Click += new System.EventHandler(this.geefdrinken_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(400, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Welzijn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(400, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Eten";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(562, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Drinken";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(400, 355);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Score";
            // 
            // Score
            // 
            this.Score.Location = new System.Drawing.Point(403, 383);
            this.Score.Name = "Score";
            this.Score.ReadOnly = true;
            this.Score.Size = new System.Drawing.Size(100, 22);
            this.Score.TabIndex = 10;
            // 
            // Welzijntimer
            // 
            this.Welzijntimer.Interval = 1500;
            this.Welzijntimer.Tick += new System.EventHandler(this.Welzijntimer_Tick);
            // 
            // Etentimer
            // 
            this.Etentimer.Interval = 1000;
            this.Etentimer.Tick += new System.EventHandler(this.Etentimer_Tick);
            // 
            // Drinkentimer
            // 
            this.Drinkentimer.Interval = 750;
            this.Drinkentimer.Tick += new System.EventHandler(this.Drinkentimer_Tick);
            // 
            // Scoretimer
            // 
            this.Scoretimer.Interval = 1000;
            this.Scoretimer.Tick += new System.EventHandler(this.Scoretimer_Tick);
            // 
            // mrcanny
            // 
            this.mrcanny.Tick += new System.EventHandler(this.mrcanny_Tick);
            // 
            // Timer
            // 
            this.Timer.Interval = 1000;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(524, 355);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Tijd";
            // 
            // Tijd
            // 
            this.Tijd.Location = new System.Drawing.Point(527, 383);
            this.Tijd.Name = "Tijd";
            this.Tijd.ReadOnly = true;
            this.Tijd.Size = new System.Drawing.Size(100, 22);
            this.Tijd.TabIndex = 12;
            // 
            // perish
            // 
            this.perish.BackColor = System.Drawing.Color.Red;
            this.perish.Location = new System.Drawing.Point(646, 371);
            this.perish.Name = "perish";
            this.perish.Size = new System.Drawing.Size(58, 34);
            this.perish.TabIndex = 13;
            this.perish.Text = "Stop";
            this.perish.UseVisualStyleBackColor = false;
            this.perish.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(752, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Dit is Mr canny simulator";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(752, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(315, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "In dit spelletje moet je zo lang mogelijk overleven";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(752, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(272, 17);
            this.label8.TabIndex = 16;
            this.label8.Text = "Als de welzijnbar leeg is is het spel voorbij";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(752, 148);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(474, 17);
            this.label9.TabIndex = 17;
            this.label9.Text = "Je kunt Mr canny eten en drinken geven, maar dit gaat wel van je score af";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(752, 185);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(298, 17);
            this.label10.TabIndex = 18;
            this.label10.Text = "Als je vastloopt kun je op de stop knop klikken";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(752, 222);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(290, 17);
            this.label11.TabIndex = 19;
            this.label11.Text = "Je eindscore wordt berekent door score * tijd";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(752, 289);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 17);
            this.label12.TabIndex = 20;
            this.label12.Text = "Veel succes";
            // 
            // Prijseten
            // 
            this.Prijseten.AutoSize = true;
            this.Prijseten.Location = new System.Drawing.Point(403, 184);
            this.Prijseten.Name = "Prijseten";
            this.Prijseten.Size = new System.Drawing.Size(63, 17);
            this.Prijseten.TabIndex = 21;
            this.Prijseten.Text = "Prijs $60";
            // 
            // Prijswater
            // 
            this.Prijswater.AutoSize = true;
            this.Prijswater.Location = new System.Drawing.Point(565, 185);
            this.Prijswater.Name = "Prijswater";
            this.Prijswater.Size = new System.Drawing.Size(63, 17);
            this.Prijswater.TabIndex = 22;
            this.Prijswater.Text = "Prijs $40";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(752, 255);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(132, 17);
            this.label13.TabIndex = 23;
            this.label13.Text = "Pas op, er is inflatie";
            // 
            // drinkenbar
            // 
            this.drinkenbar.Location = new System.Drawing.Point(565, 128);
            this.drinkenbar.Name = "drinkenbar";
            this.drinkenbar.Size = new System.Drawing.Size(156, 28);
            this.drinkenbar.TabIndex = 2;
            this.drinkenbar.Value = 100;
            // 
            // etenbar
            // 
            this.etenbar.Location = new System.Drawing.Point(403, 128);
            this.etenbar.Name = "etenbar";
            this.etenbar.Size = new System.Drawing.Size(156, 28);
            this.etenbar.TabIndex = 1;
            this.etenbar.Value = 100;
            // 
            // welzijnbar
            // 
            this.welzijnbar.Location = new System.Drawing.Point(403, 64);
            this.welzijnbar.Name = "welzijnbar";
            this.welzijnbar.Size = new System.Drawing.Size(318, 28);
            this.welzijnbar.TabIndex = 0;
            this.welzijnbar.Value = 100;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(458, 289);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 17);
            this.label14.TabIndex = 24;
            this.label14.Text = "(20%)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(618, 289);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 17);
            this.label15.TabIndex = 25;
            this.label15.Text = "(15%)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1248, 450);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Prijswater);
            this.Controls.Add(this.Prijseten);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.perish);
            this.Controls.Add(this.Tijd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.geefdrinken);
            this.Controls.Add(this.geefeten);
            this.Controls.Add(this.PB1);
            this.Controls.Add(this.drinkenbar);
            this.Controls.Add(this.etenbar);
            this.Controls.Add(this.welzijnbar);
            this.Name = "Form1";
            this.Text = "Mr canny simulator";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PB1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CustomProgressBar etenbar;
        private CustomProgressBar drinkenbar;
        private System.Windows.Forms.PictureBox PB1;
        private CustomProgressBar welzijnbar;
        private System.Windows.Forms.Button geefeten;
        private System.Windows.Forms.Button geefdrinken;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Score;
        private System.Windows.Forms.Timer Welzijntimer;
        private System.Windows.Forms.Timer Etentimer;
        private System.Windows.Forms.Timer Drinkentimer;
        private System.Windows.Forms.Timer Scoretimer;
        private System.Windows.Forms.Timer mrcanny;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Tijd;
        private System.Windows.Forms.Button perish;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Prijseten;
        private System.Windows.Forms.Label Prijswater;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}

